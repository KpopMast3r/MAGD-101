let z = 255;
let fr = 60;
let h = 3;
var d = 22.5;
var f = 175
var q = 0

function setup() {
  // put setup code here
  createCanvas(1000, 1000);
  background(0);
  colorMode(RGB, z, z, z, 1);
  frameRate(fr);
}

function draw() {

  if (keyIsPressed) {
   if (key == '1') {
    //arc 4
  fill(z, 126, q);
  strokeWeight(h);
  arc(pow(d, 2), pow(d, 2), -500, -500, radians(330), radians(35));
   }


  else if (key == '2') {
    fill(q, z, q);
  strokeWeight(h);
  arc(pow(d, 2), pow(d, 2), -500, -500, radians(90), radians(145));
  }
 

   else if (key == '3') {
    fill(128, q, 128);
  strokeWeight(h);
  arc(pow(d, 2), pow(d, 2), -500, -500, radians(210), radians(270));
  }

}
 if (mouseIsPressed == true){

    fill(q, q, z);
  strokeWeight(h);
  arc(pow(d, 2), pow(d, 2), -500, -500, radians(145), radians(210));

  fill(z, z, q);
  strokeWeight(h);
  arc(pow(d, 2), pow(d, 2), -500, -500, radians(35), radians(90));

  fill(z, q, q );
  strokeWeight(h);
  arc(pow(d, 2), pow(d, 2), -500, -500, radians(270), radians(330));
  
}

for (var i = 150; i < 1000; i +=100) {
  line(i, 900, i + 100, 100);
}

}