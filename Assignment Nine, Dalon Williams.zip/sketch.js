var theme;
var group;
var x = [200, 0, 2.5, 1];
var amp;
var mic;
var scale = 1.0;
function preload() {
  theme = loadSound("thomas-whistle.mp3");
  group = loadImage('ThomasNFriends.png');
  logo = loadImage( "TTS2.jpg");

}
function setup() {
  createCanvas(900, 830);
  colorMode(RGB, 255, 255, 255);
  x[1] = width/2;
  mic = new p5.AudioIn();
  mic.start();
  amp = new p5.Amplitude();
  amp.setInput(mic)
  capture = createCapture();
  capture.hide();
}


function draw() {
  var aspectRatio = capture.height/capture.width;
  var h = width* aspectRatio;
  background(0, 239, 249)
  //background

  image(capture, 0, 75, width, h)
   filter(INVERT); 
  //Engines
  image(group, 0, 203.33);
  //mic
  scale = map(amp.getLevel(), 0, 1.0, 10, width);
  fill(39, 160, 252 );
  ellipse( 100, 725, scale, scale);
  ellipse( 100, 100, scale, scale);
  ellipse( 800, 100, scale, scale);
  ellipse( 800, 725, scale, scale);
    
  //Logo formula  
  x[1] += x[2] * x[3];
  if ((x[1] > width - x[0]) || (x[1] < x[0])) {
    x[3] = -x[3];
    theme.play();
}
  //logo
  if (x[3] == 1) {
    push()
    translate(x[1], 640);
  ThomasAndFriend(0, 0, x[2], x[2]);
    pop();
  } else {
     translate(x[1], 10);
    ThomasAndFriend(0, 0, x[2], x[2]);
}

}

function ThomasAndFriend(x, y, width, height){
  image(logo, -200, 0);
  translate() 
}