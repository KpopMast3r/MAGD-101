var img1
var img2
var gif
var quote = "365 annoying days later..."
var squidline = "Kill My Self"

function preload(){
 img1 = loadImage("Kirk-Pineapple-8x10.jpg");
 img2 = loadImage("squid.jpg");
 gif = loadImage("spongebob.gif");
 img3 = loadImage("patricktwo.jpg");

}

function setup() {
  colorMode(RGB, 255, 255, 255);
  background(0, 0, 0);
  createCanvas(1600, 1800);
  noStroke();
}

function draw() {
  //pictures
  image(img1, 0, 0);
  image(img2, 100, 1300);
  image(gif, mouseX * 2.5, mouseY * 2.5);
  image(img3, mouseX, mouseY);
  
  //Quote
  textFont('Pacidico');
  fill(0, 11, 28);
  textSize(150);
  text(quote,55, 1775);
  
  //squidwards line
  textFont("Arial");
  fill(0, 3, 7);
  text(50);
  textSize(75);
  text(squidline, 100, 1125, 320, 400);
}


